package com.rudrila.scanner

import android.opengl.GLES11Ext
import android.opengl.GLES20
import com.google.ar.core.Coordinates2d
import com.google.ar.core.Frame
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

class CameraBackgroundRenderer {
    var textureId:Int=0; private var program=0; private var pos=0; private var uv=0; private var tex=0
    private val quad:FloatBuffer=buf(floatArrayOf(-1f,-1f, 1f,-1f, -1f,1f, 1f,1f))
    private val ndc:FloatBuffer=buf(floatArrayOf(-1f,-1f, 1f,-1f, -1f,1f, 1f,1f))
    private val texCoords:FloatBuffer=buf(FloatArray(8))
    fun create(){
        val ids=IntArray(1);GLES20.glGenTextures(1,ids,0);textureId=ids[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,textureId)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_MIN_FILTER,GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_MAG_FILTER,GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_WRAP_S,GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_WRAP_T,GLES20.GL_CLAMP_TO_EDGE)
        val vs=shader(GLES20.GL_VERTEX_SHADER,"attribute vec2 a;attribute vec2 b;varying vec2 v;void main(){gl_Position=vec4(a,0.0,1.0);v=b;}")
        val fs=shader(GLES20.GL_FRAGMENT_SHADER,"#extension GL_OES_EGL_image_external : require\nprecision mediump float;uniform samplerExternalOES s;varying vec2 v;void main(){gl_FragColor=texture2D(s,v);}")
        program=GLES20.glCreateProgram();GLES20.glAttachShader(program,vs);GLES20.glAttachShader(program,fs);GLES20.glLinkProgram(program)
        pos=GLES20.glGetAttribLocation(program,"a");uv=GLES20.glGetAttribLocation(program,"b");tex=GLES20.glGetUniformLocation(program,"s")
    }
    fun draw(frame:Frame){
        if(frame.hasDisplayGeometryChanged()){
            ndc.position(0);texCoords.position(0)
            frame.transformCoordinates2d(Coordinates2d.OPENGL_NORMALIZED_DEVICE_COORDINATES,ndc,Coordinates2d.TEXTURE_NORMALIZED,texCoords)
        }
        GLES20.glDisable(GLES20.GL_DEPTH_TEST);GLES20.glUseProgram(program)
        quad.position(0);GLES20.glVertexAttribPointer(pos,2,GLES20.GL_FLOAT,false,0,quad);GLES20.glEnableVertexAttribArray(pos)
        texCoords.position(0);GLES20.glVertexAttribPointer(uv,2,GLES20.GL_FLOAT,false,0,texCoords);GLES20.glEnableVertexAttribArray(uv)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,textureId);GLES20.glUniform1i(tex,0)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP,0,4)
        GLES20.glDisableVertexAttribArray(pos);GLES20.glDisableVertexAttribArray(uv)
    }
    private fun shader(type:Int,src:String):Int{val s=GLES20.glCreateShader(type);GLES20.glShaderSource(s,src);GLES20.glCompileShader(s);return s}
    private fun buf(a:FloatArray)=ByteBuffer.allocateDirect(a.size*4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply{put(a);position(0)}
}
