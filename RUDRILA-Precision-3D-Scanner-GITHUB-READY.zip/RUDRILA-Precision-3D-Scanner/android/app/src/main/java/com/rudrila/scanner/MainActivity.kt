package com.rudrila.scanner

import android.Manifest
import android.content.pm.PackageManager
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.ar.core.*
import com.google.ar.core.exceptions.CameraNotAvailableException
import com.rudrila.scanner.core.*
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

class MainActivity:AppCompatActivity(){
    private var session:Session?=null;private var installRequested=false;private lateinit var gl:GLSurfaceView
    private lateinit var status:TextView;private lateinit var progress:ProgressBar;private lateinit var start:Button;private lateinit var stop:Button
    private lateinit var renderer:ScannerRenderer;private val worker=Executors.newSingleThreadExecutor()
    override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main)
        gl=findViewById(R.id.gl);status=findViewById(R.id.status);progress=findViewById(R.id.progress);start=findViewById(R.id.start);stop=findViewById(R.id.stop)
        renderer=ScannerRenderer({session},{windowManager.defaultDisplay.rotation}){frames,vox->runOnUiThread{status.text="Scanning • $frames depth frames • $vox voxels";progress.progress=(frames.coerceAtMost(72)*100/72)}}
        gl.setEGLContextClientVersion(2);gl.setPreserveEGLContextOnPause(true);gl.setRenderer(renderer);gl.renderMode=GLSurfaceView.RENDERMODE_CONTINUOUSLY
        start.setOnClickListener{renderer.start();start.isEnabled=false;stop.isEnabled=true;status.text="Move slowly: low → middle → high → top"}
        stop.setOnClickListener{renderer.stop();start.isEnabled=true;stop.isEnabled=false;status.text="Building STL/3MF…";worker.execute{exportScan()}}
    }
    override fun onResume(){super.onResume();ensureSession()}
    private fun ensureSession(){
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.CAMERA),7);return}
        if(session==null){try{
            when(ArCoreApk.getInstance().requestInstall(this,!installRequested)){ArCoreApk.InstallStatus.INSTALL_REQUESTED->{installRequested=true;return};else->Unit}
            val s=Session(this);if(!s.isDepthModeSupported(Config.DepthMode.RAW_DEPTH_ONLY)){status.text="Raw Depth unsupported on this phone";return}
            s.configure(s.config.apply{depthMode=Config.DepthMode.RAW_DEPTH_ONLY;focusMode=Config.FocusMode.AUTO});session=s
        }catch(e:Exception){status.text="ARCore error: ${e.javaClass.simpleName}";return}}
        try{session?.resume();gl.onResume();status.text="READY • center object • keep 0.5–1.2 m distance"}catch(e:CameraNotAvailableException){status.text="Camera unavailable"}
    }
    override fun onPause(){super.onPause();gl.onPause();session?.pause()}
    override fun onDestroy(){session?.close();worker.shutdown();super.onDestroy()}
    override fun onRequestPermissionsResult(r:Int,p:Array<out String>,g:IntArray){super.onRequestPermissionsResult(r,p,g);if(r==7&&g.firstOrNull()==PackageManager.PERMISSION_GRANTED)ensureSession()}
    private fun exportScan(){try{
        val f=renderer.fusion();val pts=f.pointsMm();if(pts.size<100){runOnUiThread{status.text="RESCAN REQUIRED • not enough reliable depth"};return}
        val solid=Solidifier.fillToCenter(f.occupied());val mesh=VoxelMesher.mesh(solid,f.voxelSizeMm)
        val b=mesh.bounds().size;val dir=File(getExternalFilesDir(null),"scans").apply{mkdirs()};val stamp=System.currentTimeMillis()
        val stl=File(dir,"RUDRILA_scan_$stamp.stl");FileOutputStream(stl).use{StlExporter.writeBinary(mesh,it)}
        val mf=File(dir,"RUDRILA_scan_$stamp.3mf");FileOutputStream(mf).use{ThreeMfExporter.write(mesh,it)}
        val ply=File(dir,"RUDRILA_scan_$stamp.ply");FileOutputStream(ply).use{PlyExporter.writeAscii(pts,it)}
        runOnUiThread{status.text="EXPORTED • %.1f × %.1f × %.1f mm • ${dir.absolutePath}".format(b.x,b.y,b.z)}
    }catch(e:Throwable){runOnUiThread{status.text="Export failed: ${e.javaClass.simpleName}"}}}
}
