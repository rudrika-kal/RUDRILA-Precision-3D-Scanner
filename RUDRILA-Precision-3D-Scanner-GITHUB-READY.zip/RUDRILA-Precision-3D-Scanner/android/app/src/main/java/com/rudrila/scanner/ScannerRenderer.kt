package com.rudrila.scanner

import android.media.Image
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import com.google.ar.core.*
import com.google.ar.core.exceptions.NotYetAvailableException
import com.rudrila.scanner.core.*
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class ScannerRenderer(
    private val sessionProvider:()->Session?,
    private val displayRotationProvider:()->Int,
    private val onStats:(Int,Int)->Unit
):GLSurfaceView.Renderer{
    private val bg=CameraBackgroundRenderer()
    private val scanning=AtomicBoolean(false)
    private val fusion=DepthFusion(voxelSizeMm=2.0,minConfidence=160,pixelStride=1,minDepthMm=250,maxDepthMm=1800,minObservations=1)
    private var lastDepthTimestamp=-1L
    @Volatile var surfaceWidth=1; @Volatile var surfaceHeight=1
    fun start(){fusion.clear();lastDepthTimestamp=-1;scanning.set(true)}
    fun stop(){scanning.set(false)}
    fun fusion():DepthFusion=fusion
    override fun onSurfaceCreated(gl:GL10?,config:EGLConfig?){GLES20.glClearColor(0f,0f,0f,1f);bg.create()}
    override fun onSurfaceChanged(gl:GL10?,w:Int,h:Int){surfaceWidth=w;surfaceHeight=h;GLES20.glViewport(0,0,w,h)}
    override fun onDrawFrame(gl:GL10?){
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        val session=sessionProvider()?:return
        try{
            session.setCameraTextureName(bg.textureId)
            session.setDisplayGeometry(displayRotationProvider(),surfaceWidth,surfaceHeight)
            val frame=session.update(); bg.draw(frame)
            if(!scanning.get() || frame.camera.trackingState!=TrackingState.TRACKING)return
            acquire(frame)?.let{fusion.integrate(it);onStats(fusion.frameCount(),fusion.voxelCount())}
        }catch(_:Throwable){}
    }
    private fun acquire(frame:Frame):DepthFrame?{
        var depth:Image?=null;var conf:Image?=null
        try{
            depth=frame.acquireRawDepthImage16Bits();if(depth.timestamp==lastDepthTimestamp || depth.timestamp!=frame.timestamp)return null;lastDepthTimestamp=depth.timestamp
            conf=frame.acquireRawDepthConfidenceImage()
            val w=depth.width;val h=depth.height
            val d=ShortArray(w*h);val c=ByteArray(w*h)
            val dp=depth.planes[0];val db=dp.buffer.order(ByteOrder.nativeOrder())
            val cp=conf.planes[0];val cb=cp.buffer
            for(y in 0 until h)for(x in 0 until w){
                val di=y*dp.rowStride+x*dp.pixelStride
                val lo=db.get(di).toInt() and 0xff; val hi=db.get(di+1).toInt() and 0xff
                val idx=y*w+x; d[idx]=((hi shl 8) or lo).toShort()
                val ci=y*cp.rowStride+x*cp.pixelStride
                var q=cb.get(ci)
                // Precision mode scans only the central 76% ROI to suppress distant background.
                if(x<w*12/100 || x>w*88/100 || y<h*12/100 || y>h*88/100)q=0
                c[idx]=q
            }
            val ti=frame.camera.textureIntrinsics;val dims=ti.imageDimensions;val f=ti.focalLength;val p=ti.principalPoint
            val intr=Intrinsics(f[0].toDouble()*w/dims[0],f[1].toDouble()*h/dims[1],p[0].toDouble()*w/dims[0],p[1].toDouble()*h/dims[1])
            val m=FloatArray(16);frame.camera.pose.toMatrix(m,0)
            return DepthFrame(w,h,d,c,intr,Mat4(DoubleArray(16){m[it].toDouble()}),depth.timestamp)
        }catch(_:NotYetAvailableException){return null}finally{depth?.close();conf?.close()}
    }
}
