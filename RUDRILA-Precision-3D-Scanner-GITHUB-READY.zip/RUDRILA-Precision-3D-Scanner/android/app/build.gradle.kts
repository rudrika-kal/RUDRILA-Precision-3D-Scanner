plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    sourceSets.getByName("main").java.srcDir("../../core/src")
    namespace="com.rudrila.scanner"
    compileSdk=36
    defaultConfig { applicationId="com.rudrila.precision3dscanner"; minSdk=24; targetSdk=36; versionCode=1; versionName="0.1.0-alpha" }
    buildTypes { release { isMinifyEnabled=false } }
    compileOptions { sourceCompatibility=JavaVersion.VERSION_17; targetCompatibility=JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget="17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.google.ar:core:1.56.0")
}
