#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="$HERE/out"
rm -rf "$OUT"; mkdir -p "$OUT"
kotlinc "$HERE"/src/com/rudrila/scanner/core/*.kt "$HERE"/test/CoreTests.kt -include-runtime -d "$OUT/core-tests.jar"
java -jar "$OUT/core-tests.jar"
