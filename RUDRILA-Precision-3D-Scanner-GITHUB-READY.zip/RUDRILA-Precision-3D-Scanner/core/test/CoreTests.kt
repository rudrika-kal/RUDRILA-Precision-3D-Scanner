import com.rudrila.scanner.core.*
import java.io.*
import java.util.zip.ZipInputStream
import kotlin.math.abs

private fun checkNear(a:Double,b:Double,t:Double,msg:String){ check(abs(a-b)<=t){"$msg: $a vs $b"} }

fun main(){
    println("TEST 1 calibration robust solve")
    val cal=CalibrationSolver.solve(listOf(
        ScaleObservation(99.5,100.0),ScaleObservation(49.75,50.0),ScaleObservation(149.25,150.0),ScaleObservation(70.0,100.0)
    ),0.10)
    check(cal.used==3)
    check(cal.passed)
    checkNear(cal.scale,100.0/99.5,1e-9,"scale")

    println("TEST 2 coverage")
    val c=CoverageTracker(azBins=8,elBins=3)
    val center=Vec3(0.0,0.0,0.0)
    for(e in listOf(-400.0,0.0,600.0)) for(i in 0 until 8){
        val a=2*Math.PI*i/8; c.addCamera(Vec3(1000*Math.cos(a),e,1000*Math.sin(a)),center)
    }
    check(c.fraction()>=0.99){"coverage ${c.fraction()}"}

    println("TEST 3 voxel mesher exact cube dimensions")
    val occ=mutableSetOf<VoxelKey>()
    for(x in 0 until 10)for(y in 0 until 20)for(z in 0 until 30)occ+=VoxelKey(x,y,z)
    val mesh=VoxelMesher.mesh(occ,1.0)
    val b=mesh.bounds().size
    checkNear(b.x,10.0,1e-9,"X"); checkNear(b.y,20.0,1e-9,"Y"); checkNear(b.z,30.0,1e-9,"Z")
    check(mesh.triangles.size==2*(10*20*2 + 10*30*2 + 20*30*2)) {"triangles ${mesh.triangles.size}"}

    println("TEST 4 STL byte count")
    val stl=ByteArrayOutputStream(); StlExporter.writeBinary(mesh,stl)
    check(stl.size()==84+50*mesh.triangles.size){"STL bytes ${stl.size()}"}

    println("TEST 5 3MF has explicit millimeter unit")
    val mf=ByteArrayOutputStream(); ThreeMfExporter.write(mesh,mf)
    var model=""
    ZipInputStream(ByteArrayInputStream(mf.toByteArray())).use { z ->
        while(true){val e=z.nextEntry?:break;if(e.name=="3D/3dmodel.model") model=z.readBytes().toString(Charsets.UTF_8)}
    }
    check("unit=\"millimeter\"" in model)

    println("TEST 6 synthetic depth unprojection")
    val d=shortArrayOf(1000,1000,1000,1000)
    val conf=byteArrayOf(255.toByte(),255.toByte(),255.toByte(),255.toByte())
    val fusion=DepthFusion(voxelSizeMm=1.0,minConfidence=1,pixelStride=1,minDepthMm=1,maxDepthMm=2000)
    fusion.integrate(DepthFrame(2,2,d,conf,Intrinsics(1000.0,1000.0,0.5,0.5),Mat4.identity(),1L))
    check(fusion.voxelCount()==4)
    val bb=Bounds3.of(fusion.pointsMm())
    checkNear(bb.size.x,1.0,1e-9,"depth X spread")
    checkNear(bb.size.y,1.0,1e-9,"depth Y spread")

    println("ALL_CORE_TESTS_PASS")
}
