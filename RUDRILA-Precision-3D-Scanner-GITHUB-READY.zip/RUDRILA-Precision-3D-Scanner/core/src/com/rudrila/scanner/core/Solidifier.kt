package com.rudrila.scanner.core

import kotlin.math.*

object Solidifier {
    /**
     * Converts sparse surface voxels into a printable star-convex occupancy by filling from each
     * accepted surface voxel toward the robust center. This is intentionally conservative and is
     * a fallback, not a substitute for a full TSDF/MVS reconstruction.
     */
    fun fillToCenter(surface:Set<VoxelKey>, maxSteps:Int=1200):Set<VoxelKey>{
        if(surface.isEmpty()) return emptySet()
        val xs=surface.map{it.x}.sorted(); val ys=surface.map{it.y}.sorted(); val zs=surface.map{it.z}.sorted()
        val c=VoxelKey(xs[xs.size/2],ys[ys.size/2],zs[zs.size/2])
        val out=HashSet<VoxelKey>(surface.size*3)
        out.addAll(surface)
        for(p in surface){
            val dx=c.x-p.x; val dy=c.y-p.y; val dz=c.z-p.z
            val n=max(abs(dx),max(abs(dy),abs(dz))).coerceAtMost(maxSteps)
            if(n==0)continue
            for(i in 0..n){
                val t=i.toDouble()/n
                out += VoxelKey(
                    (p.x+dx*t).roundToInt(),
                    (p.y+dy*t).roundToInt(),
                    (p.z+dz*t).roundToInt()
                )
            }
        }
        return out
    }
}
