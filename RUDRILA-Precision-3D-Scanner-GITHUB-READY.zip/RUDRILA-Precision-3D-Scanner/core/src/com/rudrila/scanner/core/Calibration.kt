package com.rudrila.scanner.core

import kotlin.math.*

data class ScaleObservation(val measuredMm: Double, val trueMm: Double) {
    init { require(measuredMm>0 && trueMm>0) }
}

data class CalibrationResult(
    val scale: Double,
    val rmsMm: Double,
    val maxAbsMm: Double,
    val used: Int,
    val passed: Boolean
)

object CalibrationSolver {
    fun solve(obs: List<ScaleObservation>, toleranceMm: Double = 0.5): CalibrationResult {
        require(obs.size>=2)
        val ratios=obs.map{it.trueMm/it.measuredMm}.sorted()
        val median=if(ratios.size%2==1) ratios[ratios.size/2] else (ratios[ratios.size/2-1]+ratios[ratios.size/2])/2
        // Reject scale-ratio outliers >2% from robust median.
        val good=obs.filter{abs((it.trueMm/it.measuredMm)/median - 1.0)<=0.02}
        require(good.size>=2)
        // Least squares scalar true ~= s*measured.
        val s=good.sumOf{it.measuredMm*it.trueMm}/good.sumOf{it.measuredMm*it.measuredMm}
        val errors=good.map{s*it.measuredMm-it.trueMm}
        val rms=sqrt(errors.sumOf{it*it}/errors.size)
        val maxAbs=errors.maxOf{abs(it)}
        return CalibrationResult(s,rms,maxAbs,good.size,maxAbs<=toleranceMm)
    }
}

data class AccuracyGateResult(val passed:Boolean,val reasons:List<String>)
object AccuracyGate {
    fun evaluate(cal: CalibrationResult, coverage: Double, minCoverage:Double=0.80, minFrames:Int, frames:Int):AccuracyGateResult{
        val r=mutableListOf<String>()
        if(!cal.passed) r += "Calibration residual ${"%.3f".format(cal.maxAbsMm)} mm exceeds tolerance"
        if(coverage<minCoverage) r += "Coverage ${"%.1f".format(coverage*100)}% below ${"%.1f".format(minCoverage*100)}%"
        if(frames<minFrames) r += "Only $frames accepted frames; need at least $minFrames"
        return AccuracyGateResult(r.isEmpty(),r)
    }
}
