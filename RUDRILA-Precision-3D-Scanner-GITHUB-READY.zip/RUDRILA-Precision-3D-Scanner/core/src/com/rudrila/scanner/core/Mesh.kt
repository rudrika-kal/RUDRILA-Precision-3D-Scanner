package com.rudrila.scanner.core

data class Triangle(val a:Vec3,val b:Vec3,val c:Vec3)
data class Mesh(val triangles:List<Triangle>){
    val vertices:List<Vec3> get()=triangles.flatMap{listOf(it.a,it.b,it.c)}
    fun bounds():Bounds3=Bounds3.of(vertices)
}

object VoxelMesher {
    private val dirs = arrayOf(
        intArrayOf(1,0,0), intArrayOf(-1,0,0), intArrayOf(0,1,0),
        intArrayOf(0,-1,0), intArrayOf(0,0,1), intArrayOf(0,0,-1)
    )
    fun mesh(occ:Set<VoxelKey>, voxelMm:Double):Mesh{
        val tris=ArrayList<Triangle>()
        for(k in occ){
            for((face,d) in dirs.withIndex()){
                val n=VoxelKey(k.x+d[0],k.y+d[1],k.z+d[2])
                if(n !in occ) emitFace(tris,k,face,voxelMm)
            }
        }
        return Mesh(tris)
    }
    private fun emitFace(out:MutableList<Triangle>,k:VoxelKey,face:Int,s:Double){
        val x=(k.x-0.5)*s; val y=(k.y-0.5)*s; val z=(k.z-0.5)*s
        fun p(dx:Int,dy:Int,dz:Int)=Vec3(x+dx*s,y+dy*s,z+dz*s)
        val q:Array<Vec3> = when(face){
            0->arrayOf(p(1,0,0),p(1,1,0),p(1,1,1),p(1,0,1))
            1->arrayOf(p(0,0,1),p(0,1,1),p(0,1,0),p(0,0,0))
            2->arrayOf(p(0,1,0),p(0,1,1),p(1,1,1),p(1,1,0))
            3->arrayOf(p(0,0,1),p(0,0,0),p(1,0,0),p(1,0,1))
            4->arrayOf(p(1,0,1),p(1,1,1),p(0,1,1),p(0,0,1))
            else->arrayOf(p(0,0,0),p(0,1,0),p(1,1,0),p(1,0,0))
        }
        out += Triangle(q[0],q[1],q[2]); out += Triangle(q[0],q[2],q[3])
    }
}

object MeshScale {
    fun apply(mesh:Mesh, scale:Double):Mesh=Mesh(mesh.triangles.map{Triangle(it.a*scale,it.b*scale,it.c*scale)})
}
