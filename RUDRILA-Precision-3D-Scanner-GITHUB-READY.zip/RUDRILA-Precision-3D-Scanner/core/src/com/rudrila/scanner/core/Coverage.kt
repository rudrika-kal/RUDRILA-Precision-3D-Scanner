package com.rudrila.scanner.core

import kotlin.math.*

class CoverageTracker(private val azBins:Int=24, private val elBins:Int=3){
    private val seen=BooleanArray(azBins*elBins)
    fun addCamera(cameraWorldMm:Vec3, objectCenterMm:Vec3){
        val d=cameraWorldMm-objectCenterMm
        if(d.norm()<1e-9)return
        var az=atan2(d.z,d.x)
        if(az<0)az+=2*PI
        val horiz=sqrt(d.x*d.x+d.z*d.z)
        val el=atan2(d.y,horiz)
        val a=((az/(2*PI))*azBins).toInt().coerceIn(0,azBins-1)
        val e=when { el < Math.toRadians(-15.0)->0; el > Math.toRadians(25.0)->2; else->1 }.coerceIn(0,elBins-1)
        seen[e*azBins+a]=true
    }
    fun fraction():Double=seen.count{it}.toDouble()/seen.size
    fun missingBins():Int=seen.count{!it}
}
