package com.rudrila.scanner.core

import kotlin.math.roundToInt

data class DepthFrame(
    val width: Int,
    val height: Int,
    val depthMm: ShortArray,
    val confidence: ByteArray,
    val intrinsics: Intrinsics,
    val cameraToWorld: Mat4,
    val timestampNanos: Long
) {
    init {
        require(depthMm.size == width*height)
        require(confidence.size == width*height)
    }
}

data class VoxelKey(val x:Int,val y:Int,val z:Int)
private data class Acc(var sx:Double=0.0,var sy:Double=0.0,var sz:Double=0.0,var n:Int=0)

class DepthFusion(
    val voxelSizeMm: Double = 1.0,
    val minConfidence: Int = 128,
    val minDepthMm: Int = 250,
    val maxDepthMm: Int = 2500,
    val pixelStride: Int = 2,
    val minObservations: Int = 1
) {
    private val voxels = LinkedHashMap<VoxelKey, Acc>()
    private var frames = 0
    private var acceptedSamples = 0L

    fun clear(){ voxels.clear(); frames=0; acceptedSamples=0 }
    fun frameCount() = frames
    fun sampleCount() = acceptedSamples
    fun voxelCount() = voxels.size

    fun integrate(frame: DepthFrame) {
        frames++
        val w=frame.width; val h=frame.height; val i=frame.intrinsics
        var v=0
        while (v<h) {
            var u=0
            while (u<w) {
                val idx=v*w+u
                val raw=frame.depthMm[idx].toInt() and 0xffff
                val conf=frame.confidence[idx].toInt() and 0xff
                if (raw in minDepthMm..maxDepthMm && conf>=minConfidence) {
                    val z=raw.toDouble() // camera mm
                    val x=(u-i.cx)*z/i.fx
                    val y=(v-i.cy)*z/i.fy
                    // ARCore camera looks along -Z in world/OpenGL convention.
                    val worldMeters=frame.cameraToWorld.transformPoint(Vec3(x/1000.0, -y/1000.0, -z/1000.0))
                    val p=worldMeters*1000.0
                    val k=VoxelKey(
                        (p.x/voxelSizeMm).roundToInt(),
                        (p.y/voxelSizeMm).roundToInt(),
                        (p.z/voxelSizeMm).roundToInt()
                    )
                    val a=voxels.getOrPut(k){Acc()}
                    a.sx+=p.x; a.sy+=p.y; a.sz+=p.z; a.n++
                    acceptedSamples++
                }
                u += pixelStride
            }
            v += pixelStride
        }
    }

    fun pointsMm(): List<Vec3> = voxels.values.asSequence()
        .filter { it.n >= minObservations }
        .map { Vec3(it.sx/it.n,it.sy/it.n,it.sz/it.n) }
        .toList()

    fun occupied(): Set<VoxelKey> = voxels.asSequence().filter { it.value.n>=minObservations }.map{it.key}.toSet()
}
