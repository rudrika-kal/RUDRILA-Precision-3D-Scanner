package com.rudrila.scanner.core

import java.io.*
import java.nio.*
import java.nio.charset.StandardCharsets
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.sqrt

object StlExporter {
    fun writeBinary(mesh:Mesh,out:OutputStream){
        val dos=DataOutputStream(BufferedOutputStream(out))
        dos.write(ByteArray(80))
        writeLEInt(dos,mesh.triangles.size)
        for(t in mesh.triangles){
            val n=normal(t)
            writeFloat(dos,n.x);writeFloat(dos,n.y);writeFloat(dos,n.z)
            for(p in listOf(t.a,t.b,t.c)){writeFloat(dos,p.x);writeFloat(dos,p.y);writeFloat(dos,p.z)}
            dos.writeByte(0);dos.writeByte(0)
        }
        dos.flush()
    }
    private fun normal(t:Triangle):Vec3{
        val u=t.b-t.a; val v=t.c-t.a
        val n=Vec3(u.y*v.z-u.z*v.y,u.z*v.x-u.x*v.z,u.x*v.y-u.y*v.x)
        val len=sqrt(n.x*n.x+n.y*n.y+n.z*n.z)
        return if(len<1e-12)Vec3(0.0,0.0,0.0) else n*(1.0/len)
    }
    private fun writeLEInt(d:DataOutputStream,v:Int){ d.writeByte(v);d.writeByte(v ushr 8);d.writeByte(v ushr 16);d.writeByte(v ushr 24) }
    private fun writeFloat(d:DataOutputStream,v:Double){ val x=java.lang.Float.floatToRawIntBits(v.toFloat()); writeLEInt(d,x) }
}

object ThreeMfExporter {
    fun write(mesh:Mesh,out:OutputStream){
        val zip=ZipOutputStream(BufferedOutputStream(out))
        put(zip,"[Content_Types].xml","""<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/></Types>""")
        put(zip,"_rels/.rels","""<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>""")
        val sb=StringBuilder(1024+mesh.triangles.size*140)
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><model unit=\"millimeter\" xml:lang=\"en-US\" xmlns=\"http://schemas.microsoft.com/3dmanufacturing/core/2015/02\"><resources><object id=\"1\" type=\"model\"><mesh><vertices>")
        val verts=ArrayList<Vec3>(); val indices=ArrayList<IntArray>()
        for(t in mesh.triangles){ val base=verts.size; verts+=t.a;verts+=t.b;verts+=t.c;indices+=intArrayOf(base,base+1,base+2) }
        for(v in verts) sb.append("<vertex x=\"").append(v.x).append("\" y=\"").append(v.y).append("\" z=\"").append(v.z).append("\"/>")
        sb.append("</vertices><triangles>")
        for(i in indices) sb.append("<triangle v1=\"").append(i[0]).append("\" v2=\"").append(i[1]).append("\" v3=\"").append(i[2]).append("\"/>")
        sb.append("</triangles></mesh></object></resources><build><item objectid=\"1\"/></build></model>")
        put(zip,"3D/3dmodel.model",sb.toString());zip.finish();zip.flush()
    }
    private fun put(z:ZipOutputStream,name:String,text:String){ z.putNextEntry(ZipEntry(name));z.write(text.toByteArray(StandardCharsets.UTF_8));z.closeEntry() }
}

object PlyExporter {
    fun writeAscii(points:List<Vec3>,out:OutputStream){
        val w=out.bufferedWriter()
        w.write("ply\nformat ascii 1.0\nelement vertex ${points.size}\nproperty float x\nproperty float y\nproperty float z\nend_header\n")
        for(p in points)w.write("${p.x} ${p.y} ${p.z}\n")
        w.flush()
    }
}
