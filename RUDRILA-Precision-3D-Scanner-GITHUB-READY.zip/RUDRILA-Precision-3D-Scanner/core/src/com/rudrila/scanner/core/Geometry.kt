package com.rudrila.scanner.core

import kotlin.math.*

data class Vec3(val x: Double, val y: Double, val z: Double) {
    operator fun plus(o: Vec3) = Vec3(x + o.x, y + o.y, z + o.z)
    operator fun minus(o: Vec3) = Vec3(x - o.x, y - o.y, z - o.z)
    operator fun times(s: Double) = Vec3(x * s, y * s, z * s)
    fun norm() = sqrt(x*x + y*y + z*z)
}

data class Mat4(val m: DoubleArray) {
    init { require(m.size == 16) }
    fun transformPoint(p: Vec3): Vec3 {
        // Column-major (OpenGL / ARCore convention).
        val x = m[0]*p.x + m[4]*p.y + m[8]*p.z + m[12]
        val y = m[1]*p.x + m[5]*p.y + m[9]*p.z + m[13]
        val z = m[2]*p.x + m[6]*p.y + m[10]*p.z + m[14]
        val w = m[3]*p.x + m[7]*p.y + m[11]*p.z + m[15]
        return if (abs(w) > 1e-12 && abs(w - 1.0) > 1e-12) Vec3(x/w, y/w, z/w) else Vec3(x,y,z)
    }
    companion object {
        fun identity() = Mat4(doubleArrayOf(
            1.0,0.0,0.0,0.0,
            0.0,1.0,0.0,0.0,
            0.0,0.0,1.0,0.0,
            0.0,0.0,0.0,1.0
        ))
    }
}

data class Intrinsics(val fx: Double, val fy: Double, val cx: Double, val cy: Double)

data class Bounds3(val min: Vec3, val max: Vec3) {
    val size: Vec3 get() = max - min
    val center: Vec3 get() = (min + max) * 0.5
    companion object {
        fun of(points: Collection<Vec3>): Bounds3 {
            require(points.isNotEmpty())
            var minX=Double.POSITIVE_INFINITY; var minY=minX; var minZ=minX
            var maxX=Double.NEGATIVE_INFINITY; var maxY=maxX; var maxZ=maxX
            for (p in points) {
                minX=min(minX,p.x); minY=min(minY,p.y); minZ=min(minZ,p.z)
                maxX=max(maxX,p.x); maxY=max(maxY,p.y); maxZ=max(maxZ,p.z)
            }
            return Bounds3(Vec3(minX,minY,minZ), Vec3(maxX,maxY,maxZ))
        }
    }
}
