# RUDRILA Precision 3D Scanner — engineering checkpoint

This is a real Android/ARCore Raw Depth scanner checkpoint, not a claim of metrology-grade final accuracy.

## Implemented
- ARCore 1.56.0 Raw Depth capture with confidence filtering.
- Camera texture preview using OpenGL OES.
- Metric unprojection using texture intrinsics scaled to the raw-depth image.
- Camera-pose transform into ARCore world coordinates.
- Central precision ROI to reduce background contamination.
- Voxel fusion in millimetres.
- Coverage/calibration/accuracy-gate core modules.
- Printable fallback solidification, boundary meshing, binary STL, explicit-mm 3MF, and PLY exports.
- JVM core regression tests for calibration, coverage, exact dimensions, STL, 3MF units, and depth unprojection.

## Not yet validated / not final
- S23 Ultra physical-camera test has NOT been run from this environment.
- Automatic fiducial/ChArUco calibration and high-quality MVS/TSDF reconstruction are not yet implemented in this checkpoint.
- The current solidifier is a conservative star-convex fallback; concave objects require the later TSDF/MVS stage.
- Therefore no 0.1 mm, 1 mm, 100%, or 101% real-world accuracy claim is made.

## Verified core test
Run `core/run_tests.sh`. Expected final line: `ALL_CORE_TESTS_PASS`.

## Android build
Open `android/` in Android Studio with SDK 36 installed, or use Gradle 8.9 and run `gradle :app:assembleDebug`. ARCore Depth support is required.

## GitHub CI
Pushes to `main` run `.github/workflows/android-build.yml`, which executes the core regression tests, builds the Android debug APK on API 36, verifies the APK ZIP, and uploads it as `RUDRILA-Precision-3D-Scanner-APK`.
